<!-- Formulaire de Connexion -->
<div class="aside">
    <img class="img_login" src="img/atlasFaranes.jpg" alt="Atlas Faranes">

    <form id="loginForm" method="post" action=""><!--Cela permettra à JavaScript de trouver le formulaire correctement lorsque l'on utilise document.getElementById('loginForm').-->
        <h1 class="lato-light-italic">Connexion</h1>
        
        <div class="txt_field">
            <input type="email" id="email" name="email" required aria-required="true" aria-label="Adresse e-mail">
            <!-- l'attribut "id" correspond à l'attribut "for" dans la balise <label> pour une meilleure accessibilité 
            Les attributs ARIA (Accessible Rich Internet Applications) aident à rendre le contenu web plus accessible aux personnes utilisant des technologies d'assistance comme les lecteurs d'écran.    
            -->
            <span></span>
            <label for="email">Saisissez une adresse e-mail :</label>
        </div>

        <div class="txt_field">
            <input type="password" id="password" name="password" required aria-required="true" aria-label="Mot de Passe">
            <span></span>
            <label for="password">Mot de Passe :</label>
        </div>

        <input id="modal-submit" class="column-6" name="submit" type="submit" value="Login">

        <div class="modal-wrapper open-modal-btn-wrapper signup_link signup_link-Reinitialiser">
            <span></span>
            <label>Réinitialiser le mot de passe ?</label>
            <a id="reinitialiser" data-target="modalReinitialiser" href="/include/templates/reinitialiser_form.php">Réinitialiser</a>
        </div>

        <div class="signup_link signup_link-Creez">
            <span></span>
            <label>Pas de compte ? Contactez l'administrateur!</label>
            <a id="contact" href="contact.php">Contact</a>
        </div>
    </form>
</div>

<!-- Modal email ou mdp erreur -->
<div id="myModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <p>Email ou mot de passe incorrect.</p>
    </div>
</div>

<!-- Modal Reinitialiser

<div id="modalReinitialiser" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form id="reinitialiserForm" method="post" action="#">
            <h1 class="lato-light-italic">Réinitialiser votre mot de passe</h1>
            <label for="emailReinitialiser">Entrez votre adresse e-mail pour réinitialiser votre mot de passe:</label>
            <input type="email" id="emailReinitialiser" name="emailReinitialiser" required aria-required="true" aria-label="Adresse e-mail">
            <input type="submit" value="Réinitialiser">
            <div class="error-message"></div>
            <div class="success-message"></div>
            <div class="reset-password-link">
                <a href="#">Mot de passe oublié?</a>

            </div>
            <div class="back-to-login-link">
                <a href="/login.php">Retour à la connexion</a>
            </div>
            
     
      </form>  
    </div>

</div>
 -->
<!-- CSS -->
<style>
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
</style>

<!-- JS -->
<script>
    document.addEventListener("DOMContentLoaded", function() {// Ce code s'exécute lorsque le DOM est entièrement chargé
   // Ce code s'exécute lorsque le DOM est entièrement chargé
            var modal = document.getElementById('myModal');
            var span = document.getElementsByClassName("close")[0];

            if (modal && span) {
                span.onclick = function() {
                    modal.style.display = "none";
                }

               
            // Affiche le modal si l'authentification échoue
            var loginError = "<?php echo isset($loginError) && $loginError ? 'true' : 'false'; ?>";            
            console.log('loginError:', loginError);
            if (loginError === 'true') {
                modal.style.display = "block";
            }
            } else {
                console.error("Element with ID 'myModal', class 'close', or form 'loginForm' not found.");
            }
        });
// Pour s'assurer que le formulaire est bien intercepté lors de sa soumission et que les valeurs d'e-mail et de mot de passe sont correctement récupérées,on ajoute des console.log dans le gestionnaire d'événements
// console.log juste après l'appel à event.preventDefault() pour vérifier que le formulaire est bien intercepté
// console.log pour afficher les valeurs des champs d'e-mail et de mot de passe afin de vérifier qu'elles sont correctement récupérées
// La soumission du formulaire est interceptée et le comportement par défaut (soumission) est empêché
// Un message "Form submitted" s'affiche dans la console pour vérifier que l'événement de soumission est bien intercepté.
// Les valeurs des champs d'e-mail et de mot de passe sont affichées dans la console pour vérifier qu'elles sont correctement récupérées.
</script>

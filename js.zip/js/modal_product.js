
document.addEventListener("DOMContentLoaded", function() {
    // Ajoute un écouteur sur le bouton d'ouverture du modal pour les produits
    document.querySelectorAll(".open-product-modal-btn").forEach(button => {
        button.addEventListener("click", function() {
            const productId = this.getAttribute("data-id");
            console.log('productId:', productId);
            
            // Récupère le formulaire de la modale correspondant au produit
            const modal = document.getElementById("product-modal-" + productId);
            modal.style.display = "block";
            
            // Ajoute l'ID du produit au champ caché dans le formulaire dans la modale
            const modalForm = modal.querySelector("form");
            if (modalForm) {
                const hiddenInput = modalForm.querySelector("input[name='Device_id']");
                if (hiddenInput) {
                    hiddenInput.value = productId;
                }
            }
        });
    });


    // Ajoute des écouteurs sur les boutons de fermeture du modal
    document.querySelectorAll(".close-modal-btn").forEach(button => {
        button.addEventListener("click", function() {
            this.closest(".modal-overlay").style.display = "none";
        });
    });

        // Ajoute des écouteurs sur les modals pour fermer lors d'un clic à l'extérieur
    document.querySelectorAll(".modal-overlay").forEach(modal => {
        modal.addEventListener("click", function(e) {
            if (e.target === this) {
                this.style.display = "none";
            }
        });
    });
});


<?php
include $_SERVER['DOCUMENT_ROOT'] . '/Include/Protect.php';
include $_SERVER['DOCUMENT_ROOT'] . '/Admin/Include/Header.php';

// Logique pour gérer les réservations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Gérer l'ajout, la modification ou la suppression d'une réservation
}

?>

<h1>Gestion des Réservations</h1>
<!-- Formulaire pour ajouter ou modifier une réservation -->
<form method="POST">
    <label for="client">Client :</label>
    <input type="text" id="client" name="client" required>
    <label for="produit">Produit :</label>
    <input type="text" id="produit" name="produit" required>
    <button type="submit">Enregistrer</button>
</form>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/include/footer.php'; ?>

<?php
include $_SERVER['DOCUMENT_ROOT'] . '/Include/Protect.php';
include $_SERVER['DOCUMENT_ROOT'] . '/Admin/Include/Header.php';

// Logique pour gérer les clients
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Gérer l'ajout, la modification ou la suppression d'un client
}

?>

<h1>Gestion des Clients</h1>
<!-- Formulaire pour ajouter ou modifier un client -->
<form method="POST">
    <label for="nom">Nom :</label>
    <input type="text" id="nom" name="nom" required>
    <label for="prenom">Prénom :</label>
    <input type="text" id="prenom" name="prenom" required>
    <button type="submit">Enregistrer</button>
</form>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/Admin/Include/Footer.php'; ?>
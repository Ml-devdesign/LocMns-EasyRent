<?php
// Configuration de la base de données
require_once $_SERVER["DOCUMENT_ROOT"] . "/admin/include/connect.php";
// Sécurité : Vérifier si l'utilisateur est authentifié avant d'exécuter le processus
include $_SERVER["DOCUMENT_ROOT"] . "/admin/include/protect.php";

// Séparation des préoccupations : Le fichier process.php ne contient que la logique de traitement des données des clients


// Initialisation des variables par défaut
$customer = [
    'Customer_id' => '',
    'Customer_firstName' => '',
    'Customer_lastName' => '',
    'Customer_email' => '',
    'Customer_password' => '',
    'Customer_adress' => '',
    'Customer_zipCode' => '',
    'Customer_phoneNum' => '',
    'Admin_booleen' => '',
    'Authorisation_id' => ''
];


// Form  validation
// Récupérer les données du client s'il y a un ID spécifié
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $customerId = $_GET['id'];
    $sql = "SELECT * FROM customer WHERE Customer_id = :customer_id";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':customer_id', $customerId, PDO::PARAM_INT);
    $stmt->execute();
    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

    // Vérifier si le client existe
    if (!$customer) {
        echo 'Client non trouvé.';
        exit; 
    }
}



// Vérification si le formulaire a été soumis pour création ou mise à jour
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validation des données d'entrée (exemple : validation de l'email  afin qu'elles répondent à des exigences strictes)
    $email = filter_var($_POST['Customer_email'], FILTER_VALIDATE_EMAIL);
    if (!$email) {
        // Gérer l'erreur, par exemple afficher un message à l'utilisateur et arrêter l'exécution du script
        echo 'Email invalide.';
        exit;
    }

    // Utilisation de requêtes préparées PDO pour éviter les injections SQL
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerId = $_POST['Customer_id'];
    $firstName = $_POST['Customer_firstName'];
    $lastName = $_POST['Customer_lastName'];
    $password = password_hash($_POST['Customer_password'], PASSWORD_DEFAULT); // Ne pas stocker les mots de passe en clair dans la base de données
    $adress = $_POST['Customer_adress'];
    $zipCode = $_POST['Customer_zipCode'];
    $phoneNum = $_POST['Customer_phoneNum'];
    $admin = isset($_POST['Admin_booleen']) ? 1 : 0;
    $authId = $_POST['Authorisation_id'];

        // Préparation de la requête SQL en fonction de la présence ou non d'un ID client
        if (empty($customerId)) {
            // Création d'un nouveau client
            // Utilisation de requêtes préparées PDO
            $sql = "INSERT INTO customer 
                                (Customer_firstName, 
                                Customer_lastName, 
                                Customer_email, 
                                Customer_password, 
                                Customer_adress, 
                                Customer_zipCode, 
                                Customer_phoneNum, 
                                Admin_booleen, 
                                Authorisation_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $db->prepare($sql);
            $stmt->execute([$firstName, 
                            $lastName, 
                            $email, 
                            $password, 
                            $adress, 
                            $zipCode, 
                            $phoneNum, 
                            $admin, 
                            $authId]);
            echo "Client créé avec succès.<br>";
    } else {
        // Mise à jour d'un client existant
        $sql = "UPDATE customer SET 
                Customer_firstName = ?, 
                Customer_lastName = ?, 
                Customer_email = ?, 
                Customer_password = ?, 
                Customer_adress = ?, 
                Customer_zipCode = ?, 
                Customer_phoneNum = ?, 
                Admin_booleen = ?, 
                Authorisation_id = ? 
                WHERE Customer_id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$firstName, 
                        $lastName, 
                        $email, 
                        $password, 
                        $adress, 
                        $zipCode, 
                        $phoneNum, 
                        $admin, 
                        $authId, 
                        $customerId]);
        echo "Client mis à jour avec succès.<br>";
    }
    header("Location: /admin/public/index.php");
    }
}
?>
<!-- 
// Récupérer les informations du client pour modification
// if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['customerId'])) {
//     $sql = "SELECT * FROM customer WHERE Customer_id = ?";
//     $stmt = $db->prepare($sql);
//     $stmt->execute([$_GET['customerId']]);
//     $customer = $stmt->fetch(PDO::FETCH_ASSOC);
// }

// // Suppression d'un client
// if (isset($_POST['action']) && $_POST['action'] == 'delete' && isset($_POST['customerId'])) {
//     $sql = "DELETE FROM customer WHERE Customer_id = ?";
//     $stmt = $db->prepare($sql);
//     $stmt->execute([$_POST['customerId']]);
//     echo "Client supprimé avec succès.<br>";
// } -->



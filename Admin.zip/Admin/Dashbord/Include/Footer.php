    <footer class="nav-area ">
    <label class="logo">
        <span class="logo-noir" >Easy</span>
            <img class="logo-img" src="/img/logosansmarque-removebg-preview.png" alt="">
        <span class="logo-orange">Rent</span>
    </label>    
   <a> &copy; 2024 Easy Rent. All rights reserved.</a></li></ul>
    </footer>
</body>
</html>
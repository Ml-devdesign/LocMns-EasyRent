<?php
include $_SERVER['DOCUMENT_ROOT'] . '/Include/Protect.php';
include $_SERVER['DOCUMENT_ROOT'] . '/Admin/Include/Header.php';

// Logique pour gérer les produits
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Gérer l'ajout, la modification ou la suppression d'un produit
}

?>

<h1>Gestion des Produits</h1>
<!-- Formulaire pour ajouter ou modifier un produit -->
<form method="POST">
    <label for="nom">Nom du produit :</label>
    <input type="text" id="nom" name="nom" required>
    <label for="description">Description :</label>
    <input type="text" id="description" name="description" required>
    <button type="submit">Enregistrer</button>
</form>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/admin/include/footer.php'; ?>

<div class="dash_img-bgCover"></div>
 <!-- 
 Index dashboard Admin
 dashboard_admin/ : Pages et fonctionnalités du tableau de bord administrateur.
--> 
<div class="p">

    <div class="display">
        <!-- Barre de recherche -->
        <div class="rond container_Customer">
            <label for="site-search">
                <span class="material-symbols-outlined">search</span>
            </label>
            <input class="rond" type="search" id="site-search" placeholder="Search.."/>
        </div>
    </div>

    <!-- Section Clients -->
    <div class="display">
        <div class="container_Customer">
            <div class="card_header">
                <span class="material-symbols-outlined">person</span>
                <h2>Clients</h2>
                <button id="viewMoreCustomers" class="btn outline">Voir Plus</button>
            </div>
            <div id="customersContainer" class="card_customer">
                <?php include __DIR__ . '/customer/customer.php'; ?>    
            </div>
        </div> 

        <!-- Section Produits -->
        <div class="container_Customer">
            <div class="card_header">
                <span class="material-symbols-outlined">shopping_cart</span>
                <h2>Produits</h2>
                <button id="viewMoreProducts" class="btn outline">Voir Plus</button>
            </div>
            <div id="productsContainer" class="card_customer">
                <?php include __DIR__ . '/products/product.php'; ?>    
            </div>       
        </div> 

        <!-- Section Réservations -->
        <div class="container_Customer">
            <div class="card_header">
                <span class="material-symbols-outlined">shopping_cart</span>
                <h2>Réservations</h2>
                <button id="viewMoreReservations" class="btn outline">Voir Plus</button>
            </div>
            <div id="reservationsContainer" class="card_customer">
                <?php include __DIR__ . '/reservations/reservation.php'; ?>    
            </div>        
        </div>
    </div>

    <div class="display">
        <!-- Formulaire de suppression -->
        <form class="glassmorphism display" method="post" action="process.php">
            <h2>Supprimer un client</h2>
            <input type="hidden" name="action" value="delete">
            <label>ID Client: <input type="text" name="customerId"></label><br>
            <button type="submit">Supprimer</button>
        </form>

        <!-- Formulaire de lecture -->
        <form class="glassmorphism display" method="get" action="process.php">
            <h2>Lire un client</h2>
            <input type="hidden" name="action" value="read">
            <label>ID Client: <input type="text" name="customerId"></label><br>
            <button type="submit">Lire</button>
        </form>
    </div>
</div>
    <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Fonction pour basculer la visibilité d'un conteneur spécifique
                function toggleVisibility(buttonId, containerId) {
                    // Sélectionne le bouton par son ID
                    const button = document.getElementById(buttonId);
                    // Sélectionne le conteneur par son ID
                    const container = document.getElementById(containerId);

                    // Vérifie que les éléments existent
                    if (button && container) {
                        // Ajoute un écouteur d'événement 'click' au bouton
                        button.addEventListener('click', function() {
                            // Bascule l'affichage du conteneur
                            if (container.style.display === 'none' || container.style.display === '') {
                                container.style.display = 'block'; // Afficher le conteneur
                            } else {
                                container.style.display = 'none'; // Masquer le conteneur
                            }
                        });
                    } else {
                        console.error(`Element with ID "${buttonId}" or "${containerId}" not found.`);
                    }
                }

                // Appelle la fonction pour le conteneur des clients
                toggleVisibility('viewMoreCustomers', 'customersContainer');
                // Appelle la fonction pour le conteneur des produits
                toggleVisibility('viewMoreProducts', 'productsContainer');
                toggleVisibility('viewMoreReservations', 'reservationsContainer');

            // Forcer l'affichage des conteneurs pour le débogage
            console.log('Forcer le bloc d\'affichage pour le débogage');
            document.getElementById('customersContainer').style.display = 'block';
            document.getElementById('productsContainer').style.display = 'block';
            document.getElementById('reservationsContainer').style.display = 'block';
        });
    </script>
<!-- https://dribbble.com/shots/23870293-Apple-Vision-Pro-Spatial-UI-Health-App# -->
<!-- https://dribbble.com/shots/22366260-Brain-Activity-Medical-UI-Data-Visualization -->
<!--Font = Pour que lelien fonctionne ne pas oublier le outline dans les filtre
    https://fonts.google.com/icons?selected=Material+Symbols+Outlined:shopping_cart:FILL@0;wght@300;GRAD@0;opsz@24&icon.size=24&icon.color=%23FFFFFF&icon.platform=web&icon.category=Business%26Payments&icon.style=Outlined -->
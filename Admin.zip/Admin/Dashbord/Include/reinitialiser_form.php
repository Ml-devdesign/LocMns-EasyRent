<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/include/connect.php";
// include $_SERVER["DOCUMENT_ROOT"] . "/admin/include/protect.php";
// require_once $_SERVER["DOCUMENT_ROOT"] . "/admin/dashboard_admin/customer/process.php";

if(empty($_POST['Customer_email'])){
    $errors['Customer_email'] = "Veuillez saisir un email valide";
}else{
    $Customer_email = $_POST['Customer_email'];
}
?>

    <form class="p container_Customer display_column" method="POST" action="">
        <!-- Ternaire renvoi du vide dans l'html pour que ce sdoit plus propre  -->
        <!-- <input  type="hidden" name="Customer_id" value="<?= htmlspecialchars(isset($customers['Customer_id'])) ? htmlspecialchars($customers['Customer_id']) : ''; ?>"> -->

         <!--<input  type="hidden" name="Customer_id" value="<?= htmlspecialchars(isset($customers['Customer_id'])); ?>"> -->

    <h1 class="p">Réinitialiser mon Mot de Passe </h1>        

        <br>

        <label>
            Email:
             <br>
            <input class="p glassmorphism" type="text" name="Customer_email" pattern="^[\w.-]+@([\w-]+\.)+[\w-]{2,4}$" value="">

        </label>
        <br>
        
        <button type="submit">Generer un mdp alea</button>
    </form>

       <!-- <input class="p glassmorphism" type="text" name="Customer_email" pattern="^[\w.-]+@([\w-]+\.)+[\w-]{2,4}$"  value="<?= htmlspecialchars($customers['Customer_email']); ?>"> -->



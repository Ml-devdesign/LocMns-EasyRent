<br>echo "Inclure Header.php<br>";
<div class="nav-area">
    <label class="logo">
        <span class="logo-noir" >Easy</span>
            <img class="logo-img" src="/img/logosansmarque-removebg-preview.png" alt="">
        <span class="logo-orange">Rent</span>
    </label>
    <input type="checkbox" id="box">
     <!-- label avec l'attribut for="box icône du menu burger -->
    <label for="box" class="btn-area">
        <span>&#9776;</span>
    </label>
    <ul>
        <li><a href="/index.php">Accueil</a></li>
        <li><a href="/public/catalogue.php">Catalogue</a></li>
        <li><a href="#">Nos services</a></li>
        <li><a href="#">Contact</a></li>
        <?php if (!isset($_SESSION['logged_in'])): ?>
        <li><a href="/login.php">Connexion</a></li>
            <?php else: ?>
        <li><a href="/logout.php">Deconnexion</a></li>
            <?php endif; ?>
    </ul>
</div>

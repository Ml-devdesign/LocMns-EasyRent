<?php
// Variables d'environnement pour la connexion à la base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'easyrent');
define('DB_USER', 'root');
define('DB_PASS', '');


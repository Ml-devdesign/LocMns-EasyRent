<?php
require_once $_SERVER["DOCUMENT_ROOT"] . "/admin/include/connect.php";
// include $_SERVER["DOCUMENT_ROOT"] . "/admin/include/protect.php";
require_once $_SERVER["DOCUMENT_ROOT"] . "/admin/dashboard_admin/products/process.php";

// Initialiser la variable $models avec un tableau vide
$models = [];
//Bloc try-catch pour la Gestion des Erreurs :
// Ce bloc tente d'exécuter les requêtes SQL et capture les exceptions en cas d'erreur. La vérification de $_GET['id'] garantit que l'ID est bien défini et est un nombre.
try {
    // if (isset($_GET['id']) && is_numeric($_GET['id'])) {
 

        // Requête SQL pour récupérer les modèles et catégories de dispositifs
        $sql = "SELECT dm.Device_model_id, dm.Device_modelName, dc.Device_category_id, dc.Device_category_name
                FROM device_model dm
                LEFT JOIN device_category dc
                ON dm.Device_category_id = dc.Device_category_id";

        // Requête SQL pour sélectionner tous les modèles de dispositif
        $stmt = $db->query($sql);
        // Vérifiez si la requête a réussi
        if ($stmt) {
            // Récupération de tous les enregistrements sous forme de tableau associatif
            $models = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Affichage pour le débogage
            echo '<pre>';
            print_r($models);
            echo '</pre>';
        // } else {
            // Si la requête a échoué, affichez un message d'erreur
            // echo "Erreur lors de l'exécution de la requête SQL.";
        // }
    } else {
        echo "ID non défini ou non valide.";
               echo "Valeur de ID: ";
        var_dump(isset($_GET['id']) ? $_GET['id'] : "Non défini");
        echo "Est numérique: ";
        var_dump(is_numeric($_GET['id']));
    }
} catch (PDOException $e) {
    // Si une erreur se produit lors de l'exécution des requêtes, elle est capturée et un message d'erreur est affiché.
    echo "Erreur lors du traitement des modèles de dispositifs : " . htmlspecialchars($e->getMessage());
}



    
?>

 <!--<?php var_dump($product)?>-->

    <form class="p container_dash display_column" method="post" action="process.php">
        <!-- Formulaire pour ajout et ou modification avec recuperation de donee via l'id   -->
        <input  type="hidden" name="Device_id" value="<?= htmlspecialchars(isset($product['Device_id']) ? $product['Device_id'] : '' )?>">
        <h1 class="">Modifier le Produit <?=htmlspecialchars($product['Device_name']) . ' ' .'Id : '. htmlspecialchars($product['Device_id']) ?></h1>        
        <label>
            Nom : <br>
            <input class="p glassmorphism" type="text" name="Device_name" value="<?= htmlspecialchars($product['Device_name']); ?>">
        </label>  
        <br>

        <!--Select--> 
        <label>
            Model :<br> 
            <div class="box-Device_model">
                <select name="Device_model_id">
                <?php 
                    if (!empty($models)) {
                        foreach ($models as $model) {
                            //Sélection du modèle et de la catégorie actuels : Pour les menus déroulants de modèle et de catégorie, il serait utile de marquer l'option actuellement sélectionnée comme selected pour refléter l'état actuel du produit que vous modifiez.
                            $selected = ($model['Device_model_id'] == $product['Device_model_id']) ? 'selected' : '';
                            echo '<option value="' . htmlspecialchars($model['Device_model_id']) . '" ' . $selected . '>' . htmlspecialchars($model['Device_modelName']) . '</option>';
                        }
                    }
                ?>
                </select>
            </div>
        </label>
        <br>

        <!--Select--> 
        <!-- Pour que les données soient correctement enregistrées dans la base de données lors de la soumission du formulaire, vous devez vous assurer que les valeurs sélectionnées dans les menus déroulants pour les attributs Device_model_id et Device_category_id sont envoyées dans la requête de soumission du formulaire. -->
        <label>
            Categorie : <br>
            <div class="box-Device_model">
                <select name="Device_category_id">
                <?php 
                    if (!empty($models)) {
                        foreach ($models as $model) {
                             $selected = ($model['Device_category_id'] == $product['Device_category_id']) ? 'selected' : '';
                            echo '<option value="' . htmlspecialchars($model['Device_category_id']) . '">' . htmlspecialchars($model['Device_category_name']) . '</option>';                
                        }
                    }
                ?>
                </select >
            </div>
        </label>
        <br>


        <label>
            Status : <br>
            <input class="p glassmorphism" type="text" name="Device_status" value="<?= htmlspecialchars($product['Device_status']); ?>">
        </label>
        
        <br>
        <label>
            Date d'entrée: <br>
            <input class="p glassmorphism" type="date" name="Device_entryDate" value="<?= htmlspecialchars($product['Device_entryDate']); ?>">
        </label>
        <br>
        <label>
            Date de Sortie : <br>
            <input class="p glassmorphism" type="date" name="Device_exitDate" value="<?= htmlspecialchars($product['Device_exitDate']); ?>">
        </label>
        <br>
        <label>
            Prix : <br>
            <input class="p glassmorphism" type="number" name="Device_priceRent" value="<?= htmlspecialchars($product['Device_priceRent']); ?>">
        </label>
        <br>
        <!-- <label>Image: <input class="glassmorphism display" type="text" name="Customer_image" value="<?= htmlspecialchars($customer['Customer_image']); ?>"></label><br> -->
        <label>
            Description: <br>
        <textarea class="p glassmorphism" name="Device_description"><?= htmlspecialchars($product['Device_description']); ?></textarea>
        </label>
        <br>

        <button type="submit"><?= empty($product['Device_id']) ? 'Créer' : 'Mettre à jour'; ?></button>
        </form>

        <!-- Formulaire de suppression -->
        <!-- <form class="glassmorphism display" method="post" action="process.php">
            <h2>Supprimer un Produit</h2>
            <input type="hidden" name="action" value="delete">
            <label>ID Produit: <input type="text" name="Device_id"></label><br>
            <button type="submit">Supprimer</button>
        </form> -->

        <!-- Formulaire de lecture -->
        <!-- <form class="glassmorphism display" method="get" action="process.php">
            <h2>Lire un Produit</h2>
            <input type="hidden" name="action" value="read">
            <label>ID Produit: <input type="text" name="Device_id"></label><br>
            <button type="submit">Lire</button>
        </form> -->

